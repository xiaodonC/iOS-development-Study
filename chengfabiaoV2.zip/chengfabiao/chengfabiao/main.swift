//
//  main.swift
//  chengfabiao
//
//  Created by Xiaodong on 16/4/21.
//  Copyright © 2016年 Xiaodong. All rights reserved.
//

import Foundation

for row in 1...9 {
    for col in 1...row {
        print(" \(col)*\(row)=\(col*row)\t",terminator:"")
    }
    print()
}

//老师，我这有个问题想请教一下，我第一次写这个循环代码的时候(代码如下)，如果按照下面的写法，怎么改能改成99乘法表，还是只有上面一种做法呢？
/*
 for r in 1...9 {
    for c in 1...9 {
        if r <= c {
            print("\(r)*\(c)=\(r*c)")
        }
    }
    print()
}
*/