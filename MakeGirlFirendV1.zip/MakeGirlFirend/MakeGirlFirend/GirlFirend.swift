//
//  GirlFirend.swift
//  MakeGirlFirend
//
//  Created by Xiaodong on 16/4/24.
//  Copyright © 2016年 Xiaodong. All rights reserved.
//

import Foundation

public class GirlFirend {
    private var _name:String
    private var _age:Int
    
    init(name:String,age:Int){
        _name = name
        _age = age
    }
    //约会功能
    func toDate(){
        print("我和\(_name)在约会，\(_name)的年龄是\(_age).")
    }
    
}

