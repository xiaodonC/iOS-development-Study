//
//  main.swift
//  MakeGirlFirend
//
//  Created by Xiaodong on 16/4/24.
//  Copyright © 2016年 Xiaodong. All rights reserved.
//

import Foundation

//生成1000个随机年龄
var ageList = [Int]()
let min:UInt32 = 18
let max:UInt32 = 31
for y in 0...999 {
    let num = Int(arc4random_uniform(max-min)+min)
    ageList.append(num)
}
//print(ageList)

//生成1000个随机字符串名字
var nameList = [String]()
let minS:UInt32 = 3
let maxS:UInt32 = 6

func getRandomString() -> String{
    let randomString = 97 + arc4random()%26
    let char = String(Character(UnicodeScalar(randomString)))
    return char
}
for x in 0...999 {
    var s:String = ""
    let num = Int(arc4random_uniform(maxS-minS)+minS)
    for i in 1...num {
        s += getRandomString()
    }
    nameList.insert(s, atIndex: x)
    s.removeAll()
}
//print(nameList)

//创建1000个女朋友
var GFarr = [GirlFirend]()
for i in 0...999 {
    GFarr.append(GirlFirend(name: "\(nameList[i])", age: ageList[i]))
    GFarr[i].toDate()
}









