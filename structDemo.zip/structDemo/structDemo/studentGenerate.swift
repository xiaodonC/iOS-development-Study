//
//  studentGenerate.swift
//  structDemo
//
//  Created by Xiaodong on 16/4/22.
//  Copyright © 2016年 Xiaodong. All rights reserved.
//

import Foundation

let s1 = Student(name: "Mike", mathPoint: 40, engPoint: 80)
let s2 = Student(name: "Lily", mathPoint: 79.5, engPoint: 96)
let s3 = Student(name: "Peter", mathPoint: 59, engPoint: 87.5)
let s4 = Student(name: "Kate", mathPoint: 58.5, engPoint: 73)
let s5 = Student(name: "Coco", mathPoint: 83, engPoint: 49)
let s6 = Student(name: "Ivy", mathPoint: 86, engPoint: 93.5)
let s7 = Student(name: "Amy", mathPoint: 67.5, engPoint: 58)
let s8 = Student(name: "Sasa", mathPoint: 88.5, engPoint: 76.5)
let s9 = Student(name: "Lisa", mathPoint: 91, engPoint: 54.5)
let s10 = Student(name: "Ivan", mathPoint: 87, engPoint: 34)

