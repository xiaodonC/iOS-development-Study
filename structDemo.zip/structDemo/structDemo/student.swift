//
//  student.swift
//  structDemo
//
//  Created by Xiaodong on 16/4/22.
//  Copyright © 2016年 Xiaodong. All rights reserved.
//

import Foundation

struct Student {
    var name:String
    var mathPoint:Double
    var engPoint:Double
    
    init(name:String,mathPoint:Double,engPoint:Double){
        self.name = name
        self.mathPoint = mathPoint
        self.engPoint = engPoint
    }
}
//求平均数方法
func average(mathPoint:Double,engPoint:Double) -> Double {
    return ((mathPoint+engPoint)/2)
}

let students = [s1,s2,s3,s4,s5,s6,s7,s8,s9,s10]
//按照平均分排序
let studentList = students.sort(){
    (student1:Student,student2:Student) -> Bool in
    return average(student1.mathPoint,engPoint: student1.engPoint) < average(student2.mathPoint,engPoint: student2.engPoint)
}

