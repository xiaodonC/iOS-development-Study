//
//  main.swift
//  structDemo
//
//  Created by Xiaodong on 16/4/22.
//  Copyright © 2016年 Xiaodong. All rights reserved.
//

import Foundation

for student in studentList {
    print("\(student.name)的平均分是:\(average(student.mathPoint,engPoint: student.engPoint)),数学:\(student.mathPoint),英语:\(student.engPoint).")
}

